<script>
	export default {
		onLaunch: function() {
			wx.cloud.init({
			  env: 'kuang-user-3gwx0hw999ca1b62',
			  traceUser: true,
			})
		},
		
	}
</script>

<style>
	/*每个页面公共css */
</style>
